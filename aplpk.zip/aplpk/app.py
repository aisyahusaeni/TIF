from flask import Flask, render_template, request, redirect, url_for
from pymongo import MongoClient
from bson.objectid import ObjectId

app = Flask(__name__)

# Setup MongoDB
client = MongoClient('mongodb://localhost:27017/')
db = client['lpk_db']
pendaftar_collection = db['pendaftar']

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/pendaftaran', methods=['GET', 'POST'])
def pendaftaran():
    if request.method == 'POST':
        nama = request.form['nama']
        nik = request.form['nik']
        whatsapp = request.form['whatsapp']
        email = request.form['email']
        program = request.form['program']
        pendaftar_collection.insert_one({
            'nama': nama,
            'nik': nik,
            'whatsapp': whatsapp,
            'email': email,
            'program': program
        })
        return redirect(url_for('pendaftar'))
    return render_template('pendaftaran.html')

@app.route('/pendaftar')
def pendaftar():
    pendaftar_list = list(pendaftar_collection.find())
    return render_template('pendaftar.html', pendaftar_list=pendaftar_list)

@app.route('/edit/<id>', methods=['GET', 'POST'])
def edit(id):
    if request.method == 'POST':
        nama = request.form['nama']
        nik = request.form['nik']
        whatsapp = request.form['whatsapp']
        email = request.form['email']
        program = request.form['program']
        pendaftar_collection.update_one(
            {'_id': ObjectId(id)},
            {'$set': {
                'nama': nama,
                'nik': nik,
                'whatsapp': whatsapp,
                'email': email,
                'program': program
            }}
        )
        return redirect(url_for('pendaftar'))

    pendaftar = pendaftar_collection.find_one({'_id': ObjectId(id)})
    return render_template('edit.html', pendaftar=pendaftar)

@app.route('/hapus/<id>')
def hapus(id):
    pendaftar_collection.delete_one({'_id': ObjectId(id)})
    return redirect(url_for('pendaftar'))

if __name__ == '__main__':
    app.run(debug=True)
